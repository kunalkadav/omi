<?php
$myfile = fopen("record.txt", "a+") or die("Unable to open file!");
$name = $_POST["name"]. "\t";
$email = $_POST["email"]. "\t";
$subject = $_POST["subject"]. "\t";
$message = $_POST["message"]. "\n";
$full_data = $name . $email . $subject. $message;
fwrite($myfile, $full_data );

fclose($myfile);
?>

<div style="color:white; background-color: green">

    <h1>Thank You</h1>
    <p>Here is the information you have submitted:</p>
    <ol>
        <li><em>Name:</em> <?php echo $_POST["name"]?></li>
        <li><em>Email:</em> <?php echo $_POST["email"]?></li>
        <li><em>Subject:</em> <?php echo $_POST["subject"]?></li>
        <li><em>Message:</em> <?php echo $_POST["message"]?></li>
    </ol>
</div>