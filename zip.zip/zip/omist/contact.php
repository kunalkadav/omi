<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Form</title>
</head>
<body>
    <h1>Thank You</h1>
    <p>Here is the information you have submitted:</p>
    <ol>
        <li><em>Name:</em> <?php echo $_POST["name"]?></li>
        <li><em>Email:</em> <?php echo $_POST["email"]?></li>
        <li><em>Subject:</em> <?php echo $_POST["subject"]?></li>
        <li><em>Message:</em> <?php echo $_POST["message"]?></li>
    </ol>
<!--
    <?php
$myfile = fopen("record.txt", "r") or die("Unable to open file!");
echo fread($myfile,filesize("record.txt"));
fclose($myfile);
?>
-->

<?php
$myfile = fopen("record.txt", "a+") or die("Unable to open file!");
$txt = $_POST["name"]. "\n";
fwrite($myfile, $txt);
$txt = "Jane Doe\n";
fwrite($myfile, $txt);
fclose($myfile);
?>

</body>
</html>